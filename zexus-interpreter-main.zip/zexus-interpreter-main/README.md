# README moved

The main developer documentation has been moved to:

  src/README.md

Please open and edit that file for project documentation and developer guidance.
