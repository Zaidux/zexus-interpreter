#!/usr/bin/env python3
from zexus_token import *

print("=== TOKEN TYPES ===")
print(f"ACTION: {ACTION}")
print(f"COLON: {COLON}")
print(f"IDENT: {IDENT}")
print(f"LPAREN: {LPAREN}")
print(f"RPAREN: {RPAREN}")
print(f"RETURN: {RETURN}")
