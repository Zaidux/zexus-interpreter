# ~/zexus-interpreter/src/zexus/__main__.py
from .cli.main import cli

if __name__ == "__main__":
    cli()
