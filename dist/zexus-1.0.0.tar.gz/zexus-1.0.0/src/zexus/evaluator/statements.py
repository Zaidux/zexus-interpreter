# src/zexus/evaluator/statements.py
import os
import sys

from .. import zexus_ast
from ..zexus_ast import (
    Program, ExpressionStatement, BlockStatement, ReturnStatement, LetStatement, ConstStatement,
    ActionStatement, FunctionStatement, IfStatement, WhileStatement, ForEachStatement,
    TryCatchStatement, UseStatement, FromStatement, ExportStatement,
    ContractStatement, EntityStatement, VerifyStatement, ProtectStatement,
    SealStatement, MiddlewareStatement, AuthStatement, ThrottleStatement, CacheStatement,
    ComponentStatement, ThemeStatement, DebugStatement, ExternalDeclaration, AssignmentExpression,
    PrintStatement, ScreenStatement, EmbeddedCodeStatement, ExactlyStatement,
    Identifier, PropertyAccessExpression, RestrictStatement, SandboxStatement, TrailStatement,
    NativeStatement, GCStatement, InlineStatement, BufferStatement, SIMDStatement,
    DeferStatement, PatternStatement, PatternCase, EnumStatement, EnumMember, StreamStatement, WatchStatement,
    CapabilityStatement, GrantStatement, RevokeStatement, ValidateStatement, SanitizeStatement, ImmutableStatement,
    InterfaceStatement, TypeAliasStatement, ModuleStatement, PackageStatement, UsingStatement,
    ChannelStatement, SendStatement, ReceiveStatement, AtomicStatement,
    # Blockchain statements and expressions
    LedgerStatement, StateStatement, RequireStatement, RevertStatement, LimitStatement,
    TXExpression, HashExpression, SignatureExpression, VerifySignatureExpression, GasExpression
)
from ..object import (
    Environment, Integer, String, Boolean as BooleanObj, ReturnValue,
    Action, List, Map, EvaluationError, EntityDefinition, EmbeddedCode, Builtin,
    start_collecting_dependencies, stop_collecting_dependencies
)
from ..security import (
    SealedObject, SmartContract, VerifyWrapper, VerificationCheck, get_security_context,
    ProtectionPolicy, Middleware, AuthConfig, RateLimiter, CachePolicy
)
from .utils import is_error, debug_log, EVAL_SUMMARY, NULL, TRUE, FALSE, _resolve_awaitable, _zexus_to_python, _python_to_zexus, is_truthy

class StatementEvaluatorMixin:
    """Handles evaluation of statements, flow control, module loading, and security features."""
    
    def eval_program(self, statements, env):
        debug_log("eval_program", f"Processing {len(statements)} statements")
        
        # Track current environment for builtin functions
        self._current_env = env
        
        try:
            EVAL_SUMMARY['parsed_statements'] = max(EVAL_SUMMARY.get('parsed_statements', 0), len(statements))
        except Exception: 
            pass
        
        result = NULL
        for i, stmt in enumerate(statements):
            debug_log(f"  Statement {i+1}", type(stmt).__name__)
            res = self.eval_node(stmt, env)
            res = _resolve_awaitable(res)
            EVAL_SUMMARY['evaluated_statements'] += 1
            
            if isinstance(res, ReturnValue): 
                debug_log("  ReturnValue encountered", res.value)
                return res.value
            if is_error(res):
                debug_log("  Error encountered", res)
                try:
                    EVAL_SUMMARY['errors'] += 1
                except Exception:
                    pass
                return res
            result = res
        
        debug_log("eval_program completed", result)
        return result
    
    def eval_block_statement(self, block, env, stack_trace=None):
        debug_log("eval_block_statement", f"len={len(block.statements)}")
        
        try:
            EVAL_SUMMARY['max_statements_in_block'] = max(EVAL_SUMMARY.get('max_statements_in_block', 0), len(block.statements))
        except Exception:
            pass
        
        if stack_trace is None:
            stack_trace = []
        
        result = NULL
        for stmt in block.statements:
            res = self.eval_node(stmt, env, stack_trace)
            res = _resolve_awaitable(res)
            EVAL_SUMMARY['evaluated_statements'] += 1
            
            if isinstance(res, (ReturnValue, EvaluationError)):
                debug_log("  Block interrupted", res)
                if is_error(res):
                    try:
                        EVAL_SUMMARY['errors'] += 1
                    except Exception:
                        pass
                return res
            result = res
        
        debug_log("  Block completed", result)
        return result
    
    def eval_expression_statement(self, node, env, stack_trace):
        return self.eval_node(node.expression, env, stack_trace)
    
    # === VARIABLE & CONTROL FLOW ===
    
    def eval_let_statement(self, node, env, stack_trace):
        debug_log("eval_let_statement", f"let {node.name.value}")
        
        # FIXED: Evaluate value FIRST to prevent recursion issues
        value = self.eval_node(node.value, env, stack_trace)
        if is_error(value): 
            return value
        
        # Type annotation validation
        if node.type_annotation:
            type_name = node.type_annotation.value
            debug_log("eval_let_statement", f"Validating type: {type_name}")
            
            # Resolve type alias
            type_alias = env.get(type_name)
            if type_alias and hasattr(type_alias, '__class__') and type_alias.__class__.__name__ == 'TypeAlias':
                # Get the base type
                base_type = type_alias.base_type
                debug_log("eval_let_statement", f"Resolved type alias: {type_name} -> {base_type}")
                
                # Validate value type matches the base type
                if not self._validate_type(value, base_type):
                    return EvaluationError(f"Type mismatch: cannot assign {type(value).__name__} to {type_name} (expected {base_type})")
            else:
                # Direct type validation (for built-in types)
                if not self._validate_type(value, type_name):
                    return EvaluationError(f"Type mismatch: cannot assign {type(value).__name__} to {type_name}")
        
        env.set(node.name.value, value)
        return NULL
    
    def _validate_type(self, value, expected_type):
        """Validate that a value matches an expected type"""
        # Map Zexus types to Python types
        type_map = {
            'int': ('Integer',),
            'integer': ('Integer',),
            'str': ('String',),
            'string': ('String',),
            'bool': ('Boolean',),
            'boolean': ('Boolean',),
            'float': ('Float', 'Integer'),  # int can be used as float
            'array': ('Array',),
            'list': ('Array',),
            'map': ('Map',),
            'dict': ('Map',),
            'null': ('Null',),
        }
        
        value_type = type(value).__name__
        expected_types = type_map.get(expected_type.lower(), (expected_type,))
        
        return value_type in expected_types
    
    def eval_const_statement(self, node, env, stack_trace):
        debug_log("eval_const_statement", f"const {node.name.value}")
        
        # Evaluate value FIRST
        value = self.eval_node(node.value, env, stack_trace)
        if is_error(value): 
            return value
        
        # Set as const in environment
        env.set_const(node.name.value, value)
        return NULL
    
    def eval_return_statement(self, node, env, stack_trace):
        val = self.eval_node(node.return_value, env, stack_trace)
        if is_error(val): 
            return val
        return ReturnValue(val)
    
    def eval_assignment_expression(self, node, env, stack_trace):
        debug_log("eval_assignment_expression", f"Assigning to {node.name.value}")
        # Support assigning to identifiers or property access targets
        from ..object import EvaluationError, NULL

        # If target is a property access expression
        if isinstance(node.name, PropertyAccessExpression):
            # Evaluate object and property
            obj = self.eval_node(node.name.object, env, stack_trace)
            if is_error(obj):
                return obj

            prop_key = node.name.property.value

            # Evaluate value first
            value = self.eval_node(node.value, env, stack_trace)
            if is_error(value):
                return value

            # Check for seal on property
            try:
                if isinstance(obj, Map):
                    existing = obj.pairs.get(prop_key)
                    if existing is not None and existing.__class__.__name__ == 'SealedObject':
                        return EvaluationError(f"Cannot modify sealed property: {prop_key}")
                elif hasattr(obj, 'get') and hasattr(obj, 'set'):
                    existing = obj.get(prop_key)
                    if existing is not None and getattr(existing, '__class__', None) and existing.__class__.__name__ == 'SealedObject':
                        return EvaluationError(f"Cannot modify sealed property: {prop_key}")
            except Exception:
                pass

            # Enforcement: consult security restrictions for writes
            try:
                ctx = get_security_context()
                target = f"{getattr(node.name.object, 'value', str(node.name.object))}.{prop_key}"
                restriction = ctx.get_restriction(target)
            except Exception:
                restriction = None

            if restriction:
                rule = restriction.get('restriction')
                if rule == 'read-only':
                    return EvaluationError(f"Write prohibited by restriction: {target}")
                if rule == 'admin-only':
                    is_admin = bool(env.get('__is_admin__')) if env and hasattr(env, 'get') else False
                    if not is_admin:
                        return EvaluationError('Admin privileges required to modify this field')

            # Perform set
            try:
                if isinstance(obj, Map):
                    obj.pairs[prop_key] = value
                    return value
                elif hasattr(obj, 'set'):
                    obj.set(prop_key, value)
                    return value
            except Exception as e:
                return EvaluationError(str(e))

            return EvaluationError('Assignment to property failed')

        # Otherwise it's an identifier assignment
        if isinstance(node.name, Identifier):
            name = node.name.value
            target_obj = env.get(name)
            if isinstance(target_obj, SealedObject):
                return EvaluationError(f"Cannot assign to sealed object: {name}")

            value = self.eval_node(node.value, env, stack_trace)
            if is_error(value):
                return value

            try:
                env.assign(name, value)
            except ValueError as e:
                return EvaluationError(str(e))
            return value

        return EvaluationError('Invalid assignment target')
    
    def eval_try_catch_statement(self, node, env, stack_trace):
        debug_log("eval_try_catch", f"error_var: {node.error_variable.value if node.error_variable else 'error'}")
        
        try:
            result = self.eval_node(node.try_block, env, stack_trace)
            if is_error(result):
                catch_env = Environment(outer=env)
                var_name = node.error_variable.value if node.error_variable else "error"
                catch_env.set(var_name, String(str(result)))
                return self.eval_node(node.catch_block, catch_env, stack_trace)
            return result
        except Exception as e:
            catch_env = Environment(outer=env)
            var_name = node.error_variable.value if node.error_variable else "error"
            catch_env.set(var_name, String(str(e)))
            return self.eval_node(node.catch_block, catch_env, stack_trace)
    
    def eval_if_statement(self, node, env, stack_trace):
        cond = self.eval_node(node.condition, env, stack_trace)
        if is_error(cond): 
            return cond
        
        if is_truthy(cond):
            return self.eval_node(node.consequence, env, stack_trace)
        
        # Check elif conditions
        if hasattr(node, 'elif_parts') and node.elif_parts:
            for elif_condition, elif_consequence in node.elif_parts:
                elif_cond = self.eval_node(elif_condition, env, stack_trace)
                if is_error(elif_cond):
                    return elif_cond
                if is_truthy(elif_cond):
                    return self.eval_node(elif_consequence, env, stack_trace)
        
        # Check else clause
        if node.alternative:
            return self.eval_node(node.alternative, env, stack_trace)
        
        return NULL
    
    def eval_while_statement(self, node, env, stack_trace):
        result = NULL
        while True:
            cond = self.eval_node(node.condition, env, stack_trace)
            if is_error(cond): 
                return cond
            if not is_truthy(cond): 
                break
            
            result = self.eval_node(node.body, env, stack_trace)
            if isinstance(result, (ReturnValue, EvaluationError)):
                return result
        
        return result
    
    def eval_foreach_statement(self, node, env, stack_trace):
        iterable = self.eval_node(node.iterable, env, stack_trace)
        if is_error(iterable): 
            return iterable
        
        if not isinstance(iterable, List):
            return EvaluationError("ForEach expects List")
        
        result = NULL
        for item in iterable.elements:
            env.set(node.item.value, item)
            result = self.eval_node(node.body, env, stack_trace)
            if isinstance(result, (ReturnValue, EvaluationError)):
                return result
        
        return result
    
    def eval_watch_statement(self, node, env, stack_trace):
        # 1. Start collecting dependencies
        start_collecting_dependencies()
        
        # 2. Evaluate the watched expression or block
        if node.watched_expr:
            # Explicit watch: watch expr => block
            # Evaluate expression to capture dependencies
            res = self.eval_node(node.watched_expr, env, stack_trace)
            if is_error(res):
                stop_collecting_dependencies()
                return res
        else:
            # Implicit watch: watch block
            # Evaluate block to capture dependencies AND execute it
            res = self.eval_node(node.reaction, env, stack_trace)
            if is_error(res):
                stop_collecting_dependencies()
                return res
                
        # 3. Stop collecting and get dependencies
        deps = stop_collecting_dependencies()
        
        # 4. Define the reaction callback WITH GUARD against infinite recursion
        executing = [False]  # Mutable flag to track execution state
        def reaction_callback(new_val):
            if executing[0]:
                # Already executing, skip to prevent infinite loop
                return
            executing[0] = True
            try:
                # Re-evaluate the reaction block WITHOUT collecting dependencies
                self.eval_node(node.reaction, env, [])
            finally:
                executing[0] = False
            
        # 5. Register callback for each dependency
        for dep_env, name in deps:
            dep_env.add_watcher(name, reaction_callback)
            
        return NULL

    # === MODULE LOADING (FULL LOGIC) ===
    
    def _check_import_permission(self, val, importer):
        """Helper to check if a file is allowed to import a specific value."""
        allowed = getattr(val, '_allowed_files', [])
        if not allowed: 
            return True
        
        try:
            importer_norm = os.path.normpath(os.path.abspath(importer))
            for a in allowed:
                a_norm = os.path.normpath(os.path.abspath(a))
                if importer_norm == a_norm: 
                    return True
                if a in importer: 
                    return True
        except Exception:
            return False
        
        return False
    
    def eval_use_statement(self, node, env, stack_trace):
        from ..module_cache import get_cached_module, cache_module, get_module_candidates, normalize_path, invalidate_module
        
        # 1. Determine File Path
        file_path_attr = getattr(node, 'file_path', None) or getattr(node, 'embedded_ref', None)
        file_path = file_path_attr.value if hasattr(file_path_attr, 'value') else file_path_attr
        if not file_path: 
            return EvaluationError("use: missing file path")
        
        debug_log("  UseStatement loading", file_path)
        normalized_path = normalize_path(file_path)
        
        # 2. Check Cache
        module_env = get_cached_module(normalized_path)
        
        # 3. Load if not cached
        if not module_env:
            candidates = get_module_candidates(file_path)
            module_env = Environment()
            loaded = False
            parse_errors = []
            
            # Circular dependency placeholder
            try: 
                cache_module(normalized_path, module_env)
            except Exception: 
                pass
            
            for candidate in candidates:
                try:
                    if not os.path.exists(candidate): 
                        continue
                    
                    debug_log("  Found module file", candidate)
                    with open(candidate, 'r', encoding='utf-8') as f: 
                        code = f.read()
                    
                    from ..lexer import Lexer
                    from ..parser import Parser
                    
                    lexer = Lexer(code)
                    parser = Parser(lexer)
                    program = parser.parse_program()
                    
                    if getattr(parser, 'errors', None):
                        parse_errors.append((candidate, parser.errors))
                        continue
                    
                    # Recursive evaluation
                    self.eval_node(program, module_env)
                    
                    # Update cache with fully loaded env
                    cache_module(normalized_path, module_env)
                    loaded = True
                    break
                except Exception as e:
                    parse_errors.append((candidate, str(e)))
            
            if not loaded:
                try: 
                    invalidate_module(normalized_path)
                except Exception: 
                    pass
                return EvaluationError(f"Module not found or failed to load: {file_path}")
        
        # 4. Bind to Current Environment
        alias = getattr(node, 'alias', None)
        if alias:
            env.set(alias, module_env)
        else:
            # Import all exports into current scope
            try:
                exports = module_env.get_exports()
                importer_file = env.get("__file__").value if env.get("__file__") else None
                
                for name, value in exports.items():
                    if importer_file:
                        if not self._check_import_permission(value, importer_file):
                            return EvaluationError(f"Permission denied for export {name}")
                    env.set(name, value)
            except Exception:
                # Fallback: expose module as filename object
                module_name = os.path.basename(file_path)
                env.set(module_name, module_env)
        
        return NULL
    
    def eval_from_statement(self, node, env, stack_trace):
        """Full implementation of FromStatement."""
        from ..module_cache import get_cached_module, cache_module, get_module_candidates, normalize_path, invalidate_module
        
        # 1. Resolve Path
        file_path = node.file_path
        if not file_path: 
            return EvaluationError("from: missing file path")
        
        normalized_path = normalize_path(file_path)
        module_env = get_cached_module(normalized_path)
        
        # 2. Load Logic (Explicitly repeated to ensure isolation)
        if not module_env:
            candidates = get_module_candidates(file_path)
            module_env = Environment()
            loaded = False
            
            try: 
                cache_module(normalized_path, module_env)
            except Exception: 
                pass
            
            for candidate in candidates:
                try:
                    if not os.path.exists(candidate): 
                        continue
                    
                    with open(candidate, 'r', encoding='utf-8') as f: 
                        code = f.read()
                    
                    from ..lexer import Lexer
                    from ..parser import Parser
                    
                    lexer = Lexer(code)
                    parser = Parser(lexer)
                    program = parser.parse_program()
                    
                    if getattr(parser, 'errors', None): 
                        continue
                    
                    self.eval_node(program, module_env)
                    cache_module(normalized_path, module_env)
                    loaded = True
                    break
                except Exception:
                    continue
            
            if not loaded:
                try: 
                    invalidate_module(normalized_path)
                except Exception: 
                    pass
                return EvaluationError(f"From import: failed to load module {file_path}")
        
        # 3. Import Specific Names
        importer_file = env.get("__file__").value if env.get("__file__") else None
        
        for name_pair in node.imports:
            # name_pair is [source_name, dest_name] (dest_name optional)
            src = name_pair[0].value if hasattr(name_pair[0], 'value') else str(name_pair[0])
            dest = name_pair[1].value if len(name_pair) > 1 and name_pair[1] else src
            
            # Retrieve from module exports
            exports = module_env.get_exports() if hasattr(module_env, 'get_exports') else {}
            val = exports.get(src)
            
            if val is None:
                # Fallback: check if it's in the environment directly
                val = module_env.get(src)
            
            if val is None:
                return EvaluationError(f"From import: '{src}' not found in {file_path}")
            
            # Security Check
            if importer_file and not self._check_import_permission(val, importer_file):
                return EvaluationError(f"Permission denied: cannot import '{src}' into '{importer_file}'")
            
            env.set(dest, val)
        
        return NULL
    
    def eval_export_statement(self, node, env, stack_trace):
        names = []
        if hasattr(node, 'names') and node.names:
            names = [n.value for n in node.names]
        elif hasattr(node, 'name') and node.name:
            names = [node.name.value]
        
        for nm in names:
            val = env.get(nm)
            if not val: 
                return EvaluationError(f"Cannot export undefined: {nm}")
            try: 
                env.export(nm, val)
            except Exception as e: 
                return EvaluationError(f"Export failed: {str(e)}")
        
        return NULL
    
    # === SECURITY STATEMENTS (Full Logic) ===
    
    def eval_seal_statement(self, node, env, stack_trace):
        target_node = node.target
        if not target_node: 
            return EvaluationError("seal: missing target")
        
        if isinstance(target_node, Identifier):
            name = target_node.value
            val = env.get(name)
            if not val: 
                return EvaluationError(f"seal: identifier '{name}' not found")
            
            sealed = SealedObject(val)
            env.set(name, sealed)
            return sealed
        
        elif isinstance(target_node, PropertyAccessExpression):
            obj = self.eval_node(target_node.object, env, stack_trace)
            if is_error(obj): 
                return obj
            
            prop_key = target_node.property.value  # Assuming Identifier
            
            if isinstance(obj, Map):
                if prop_key not in obj.pairs: 
                    return EvaluationError(f"seal: key '{prop_key}' missing")
                
                obj.pairs[prop_key] = SealedObject(obj.pairs[prop_key])
                return obj.pairs[prop_key]
            
            if hasattr(obj, 'set') and hasattr(obj, 'get'):
                curr = obj.get(prop_key)
                if not curr: 
                    return EvaluationError(f"seal: prop '{prop_key}' missing")
                
                sealed = SealedObject(curr)
                obj.set(prop_key, sealed)
                return sealed
        
        return EvaluationError("seal: unsupported target")
    
    def eval_audit_statement(self, node, env, stack_trace):
        """Evaluate audit statement for compliance logging.
        
        Syntax: audit data_name, "action_type", [optional_timestamp];
        
        Returns a log entry dictionary with the audited data reference.
        """
        from datetime import datetime
        from ..object import String, Map
        
        # Get the data identifier
        if not isinstance(node.data_name, Identifier):
            return EvaluationError(f"audit: expected identifier, got {type(node.data_name).__name__}")
        
        data_name = node.data_name.value
        
        # Evaluate the action type string
        if isinstance(node.action_type, StringLiteral):
            action_type = node.action_type.value
        else:
            action_type_result = self.eval_node(node.action_type, env, stack_trace)
            if is_error(action_type_result):
                return action_type_result
            action_type = to_string(action_type_result)
        
        # Get optional timestamp
        timestamp = None
        if node.timestamp:
            if isinstance(node.timestamp, Identifier):
                timestamp = env.get(node.timestamp.value)
            else:
                timestamp = self.eval_node(node.timestamp, env, stack_trace)
                if is_error(timestamp):
                    return timestamp
        
        # If no timestamp provided, use current time
        if timestamp is None:
            timestamp = datetime.now().isoformat()
        else:
            timestamp = to_string(timestamp)
        
        # Get reference to the audited data
        audited_data = env.get(data_name)
        if audited_data is None:
            return EvaluationError(f"audit: identifier '{data_name}' not found")
        
        # Create audit log entry as a Map object and record via security context
        audit_log_pairs = {
            "data_name": String(data_name),
            "action": String(action_type),
            "timestamp": String(timestamp),
            "data_type": String(type(audited_data).__name__),
        }

        # Register to AuditLog via SecurityContext for persistence/inspection
        try:
            ctx = get_security_context()
            ctx.log_audit(data_name, action_type, type(audited_data).__name__, timestamp, {'source': 'audit_statement'})
            # Also emit a trail event so live traces can capture it
            ctx.emit_event('audit', {'data_name': data_name, 'action': action_type})
        except Exception:
            pass

        return Map(audit_log_pairs)
    
    def eval_restrict_statement(self, node, env, stack_trace):
        """Evaluate restrict statement for field-level access control.
        
        Syntax: restrict obj.field = "restriction_type";
        
        Returns a restriction entry with the applied rule.
        """
        from datetime import datetime, timezone
        from ..object import String, Map
        
        # Get target field information
        if not isinstance(node.target, PropertyAccessExpression):
            return EvaluationError("restrict: target must be object.field")
        
        obj_name = node.target.object.value if isinstance(node.target.object, Identifier) else str(node.target.object)
        field_name = node.target.property.value if isinstance(node.target.property, Identifier) else str(node.target.property)
        
        # Get restriction type
        if isinstance(node.restriction_type, StringLiteral):
            restriction = node.restriction_type.value
        else:
            restriction = to_string(self.eval_node(node.restriction_type, env, stack_trace))
        
        # Get the object to apply restriction
        obj = env.get(obj_name)
        if obj is None:
            return EvaluationError(f"restrict: object '{obj_name}' not found")

        # Register restriction with security context so enforcement can consult it
        try:
            ctx = get_security_context()
            entry = ctx.register_restriction(f"{obj_name}.{field_name}", field_name, restriction)
        except Exception:
            entry = None

        # Return restriction entry (include id if available)
        result_map = {
            "target": String(f"{obj_name}.{field_name}"),
            "field": String(field_name),
            "restriction": String(restriction),
            "status": String("applied"),
            "timestamp": String(datetime.now(timezone.utc).isoformat())
        }
        if entry and entry.get('id'):
            result_map['id'] = String(entry.get('id'))

        return Map(result_map)
    
    def eval_sandbox_statement(self, node, env, stack_trace):
        """Evaluate sandbox statement for isolated execution environments.
        
        Syntax: sandbox { code }
        
        Creates a new isolated environment and executes code within it.
        """

        # Create isolated environment (child of current)
        sandbox_env = Environment(parent=env)
        # Mark as running inside a sandbox and attach a default policy name
        sandbox_env.set('__in_sandbox__', True)
        # Allow caller to specify a policy on the node (future enhancement)
        sandbox_policy = getattr(node, 'policy', None) or 'default'
        sandbox_env.set('__sandbox_policy__', sandbox_policy)
        # Ensure default sandbox policy exists
        try:
            sec = get_security_context()
            if 'default' not in sec.sandbox_policies:
                # conservative default: disallow file I/O builtins
                sec.register_sandbox_policy('default', allowed_builtins=[
                    'now','timestamp','random','to_hex','from_hex','sqrt',
                    'string','len','first','rest','push','reduce','map','filter',
                    'debug_log','debug_trace'
                ])
        except Exception:
            pass

        # Execute body in sandbox
        if node.body is None:
            return NULL

        result = self.eval_node(node.body, sandbox_env, stack_trace)

        # Register sandbox run for observability
        try:
            ctx = get_security_context()
            # store a minimal summary (stringified result) for now
            result_summary = None
            try:
                result_summary = str(result)
            except Exception:
                result_summary = None
            ctx.register_sandbox_run(parent_context=getattr(env, 'name', None), policy=None, result_summary=result_summary)
        except Exception:
            pass

        # Return result from sandbox execution
        return result if result is not None else NULL
    
    def eval_trail_statement(self, node, env, stack_trace):
        """Evaluate trail statement for real-time audit/debug/print tracking.
        
        Syntax:
            trail audit;           // follow all audit events
            trail print;           // follow all print statements
            trail debug;           // follow all debug output
        
        Sets up event tracking and returns trail configuration.
        """
        from datetime import datetime, timezone
        from ..object import String, Map
        
        trail_type = node.trail_type
        filter_key = None
        
        if isinstance(node.filter_key, StringLiteral):
            filter_key = node.filter_key.value
        elif node.filter_key:
            filter_result = self.eval_node(node.filter_key, env, stack_trace)
            if not is_error(filter_result):
                filter_key = to_string(filter_result)
        
        # Register trail with security context so runtime can wire event sinks
        try:
            ctx = get_security_context()
            entry = ctx.register_trail(trail_type, filter_key)
        except Exception:
            entry = None

        # Create trail configuration entry (include id if available)
        trail_config = {
            "type": String(trail_type),
            "filter": String(filter_key) if filter_key else String("*"),
            "enabled": String("true"),
            "timestamp": String(datetime.now(timezone.utc).isoformat())
        }
        if entry and entry.get('id'):
            trail_config['id'] = String(entry.get('id'))

        return Map(trail_config)
    
    def eval_contract_statement(self, node, env, stack_trace):
        storage = {}
        for sv in node.storage_vars:
            init = NULL
            if getattr(sv, 'initial_value', None):
                init = self.eval_node(sv.initial_value, env, stack_trace)
                if is_error(init): 
                    return init
            storage[sv.name.value] = init
        
        actions = {}
        for act in node.actions:
            # Evaluate action node to get Action object
            action_obj = Action(act.parameters, act.body, env)
            actions[act.name.value] = action_obj
        
        contract = SmartContract(node.name.value, storage, actions)
        contract.deploy()
        env.set(node.name.value, contract)
        return NULL
    
    def eval_entity_statement(self, node, env, stack_trace):
        props = {}
        for prop in node.properties:
            p_name = prop.name.value
            p_type = prop.type.value
            def_val = NULL
            
            if getattr(prop, 'default_value', None):
                def_val = self.eval_node(prop.default_value, env, stack_trace)
                if is_error(def_val): 
                    return def_val
            
            props[p_name] = {"type": p_type, "default_value": def_val}
        
        entity = EntityDefinition(node.name.value, props)
        env.set(node.name.value, entity)
        return NULL
    
    def eval_verify_statement(self, node, env, stack_trace):
        target = self.eval_node(node.target, env, stack_trace)
        if is_error(target): 
            return target
        
        checks = []
        for cond in node.conditions:
            val = self.eval_node(cond, env, stack_trace)
            if is_error(val): 
                return val
            
            if callable(val) or isinstance(val, Action):
                checks.append(VerificationCheck(str(cond), lambda ctx: val))
            else:
                checks.append(VerificationCheck(str(cond), lambda ctx, v=val: v))
        
        wrapped = VerifyWrapper(target, checks, node.error_handler)
        get_security_context().register_verify_check(str(node.target), wrapped)
        return wrapped
    
    def eval_protect_statement(self, node, env, stack_trace):
        """Evaluate PROTECT statement with full policy engine integration."""
        from ..policy_engine import get_policy_registry, PolicyBuilder
        from ..object import String as StringObj
        
        # Evaluate target expression
        target = self.eval_node(node.target, env, stack_trace)
        if is_error(target): 
            return target
        
        # Get target name (for registration)
        target_name = str(node.target) if hasattr(node.target, 'value') else str(target)
        
        # Evaluate rules block
        rules_val = self.eval_node(node.rules, env, stack_trace)
        if is_error(rules_val): 
            return rules_val
        
        # Convert rules to dictionary
        rules_dict = {}
        if isinstance(rules_val, Map):
            for k, v in rules_val.pairs.items():
                key = k.value if isinstance(k, String) else str(k)
                rules_dict[key] = v
        
        # Determine enforcement level (string-based)
        enforcement_level = "strict"  # Default
        if hasattr(node, 'enforcement_level') and node.enforcement_level:
            level_str = node.enforcement_level.lower()
            if level_str in ["strict", "warn", "audit", "permissive"]:
                enforcement_level = level_str
        
        # Build policy using PolicyBuilder
        builder = PolicyBuilder(target_name)
        builder.set_enforcement(enforcement_level)
        
        # Parse rules and add to policy
        for rule_type, rule_config in rules_dict.items():
            if rule_type == "verify":
                # Add verification rules
                if isinstance(rule_config, List):
                    for condition in rule_config.elements:
                        condition_str = condition.value if hasattr(condition, 'value') else str(condition)
                        builder.add_verify_rule(condition_str)
            
            elif rule_type == "restrict":
                # Add restriction rules
                if isinstance(rule_config, Map):
                    for field, constraints in rule_config.pairs.items():
                        field_name = field.value if hasattr(field, 'value') else str(field)
                        constraint_list = []
                        if isinstance(constraints, List):
                            for c in constraints.elements:
                                constraint_str = c.value if hasattr(c, 'value') else str(c)
                                constraint_list.append(constraint_str)
                        builder.add_restrict_rule(field_name, constraint_list)
            
            elif rule_type == "audit":
                # Enable audit logging
                builder.enable_audit()
        
        # Build and register policy
        policy = builder.build()
        policy_registry = get_policy_registry()
        policy_registry.register(target_name, policy)
        
        debug_log("eval_protect_statement", f"✓ Policy registered for {target_name} (level: {enforcement_level})")
        
        # Store policy reference in environment for enforcement
        env.set(f"__policy_{target_name}__", policy)
        
        # Also register with legacy security context for backwards compatibility
        try:
            policy_legacy = ProtectionPolicy(target_name, rules_dict, enforcement_level)
            get_security_context().register_protection(target_name, policy_legacy)
        except:
            pass  # Legacy context may not be available
        
        return StringObj(f"Protection policy activated for '{target_name}' (level: {enforcement_level})")
    
    def eval_middleware_statement(self, node, env, stack_trace):
        handler = self.eval_node(node.handler, env)
        if is_error(handler): 
            return handler
        
        mw = Middleware(node.name.value, handler)
        get_security_context().middlewares[node.name.value] = mw
        return NULL
    
    def eval_auth_statement(self, node, env, stack_trace):
        config = self.eval_node(node.config, env)
        if is_error(config): 
            return config
        
        c_dict = {}
        if isinstance(config, Map):
            for k, v in config.pairs.items():
                c_dict[k.value if isinstance(k, String) else str(k)] = v
        
        get_security_context().auth_config = AuthConfig(c_dict)
        return NULL
    
    def eval_throttle_statement(self, node, env, stack_trace):
        target = self.eval_node(node.target, env)
        limits = self.eval_node(node.limits, env)
        
        rpm, burst, per_user = 100, 10, False
        if isinstance(limits, Map):
            for k, v in limits.pairs.items():
                ks = k.value if isinstance(k, String) else str(k)
                if ks == "requests_per_minute" and isinstance(v, Integer): 
                    rpm = v.value
                elif ks == "burst_size" and isinstance(v, Integer): 
                    burst = v.value
                elif ks == "per_user": 
                    per_user = True if (isinstance(v, BooleanObj) and v.value) else False
        
        limiter = RateLimiter(rpm, burst, per_user)
        ctx = get_security_context()
        if not hasattr(ctx, 'rate_limiters'): 
            ctx.rate_limiters = {}
        ctx.rate_limiters[str(node.target)] = limiter
        return NULL
    
    def eval_cache_statement(self, node, env, stack_trace):
        target = self.eval_node(node.target, env)
        policy = self.eval_node(node.policy, env)
        
        ttl, inv = 3600, []
        if isinstance(policy, Map):
            for k, v in policy.pairs.items():
                ks = k.value if isinstance(k, String) else str(k)
                if ks == "ttl" and isinstance(v, Integer): 
                    ttl = v.value
                elif ks == "invalidate_on" and isinstance(v, List):
                    inv = [x.value if hasattr(x, 'value') else str(x) for x in v.elements]
        
        cp = CachePolicy(ttl, inv)
        ctx = get_security_context()
        if not hasattr(ctx, 'cache_policies'): 
            ctx.cache_policies = {}
        ctx.cache_policies[str(node.target)] = cp
        return NULL
    


    # === MISC STATEMENTS ===
    
    def eval_print_statement(self, node, env, stack_trace):
        if not hasattr(node, 'value') or node.value is None:
            return NULL
        
        val = self.eval_node(node.value, env, stack_trace)
        if is_error(val):
            print(f"❌ Error: {val}", file=sys.stderr)
            return NULL
        # Emit print output and trail events
        output = val.inspect() if hasattr(val, 'inspect') else str(val)
        print(output)
        try:
            ctx = get_security_context()
            ctx.emit_event('print', {'value': output})
        except Exception:
            pass
        return NULL
    
    def eval_screen_statement(self, node, env, stack_trace):
        print(f"[RENDER] Screen: {node.name.value}")
        return NULL
    
    def eval_embedded_code_statement(self, node, env, stack_trace):
        obj = EmbeddedCode(node.name.value, node.language, node.code)
        env.set(node.name.value, obj)
        return NULL
    
    def eval_component_statement(self, node, env, stack_trace):
        props = None
        if hasattr(node, 'properties') and node.properties:
            val = self.eval_node(node.properties, env, stack_trace)
            if is_error(val): 
                return val
            props = _zexus_to_python(val)
        
        # Check builtin
        if hasattr(self, 'builtins') and 'define_component' in self.builtins:
            self.builtins['define_component'].fn(String(node.name.value), Map(props) if isinstance(props, dict) else NULL)
            return NULL
        
        env.set(node.name.value, String(f"<component {node.name.value}>"))
        return NULL
    
    def eval_theme_statement(self, node, env, stack_trace):
        val = self.eval_node(node.properties, env, stack_trace) if hasattr(node, 'properties') else NULL
        if is_error(val): 
            return val
        env.set(node.name.value, val)
        return NULL
    
    def eval_debug_statement(self, node, env, stack_trace):
        val = self.eval_node(node.value, env, stack_trace)
        if is_error(val): 
            return val
        
        from ..object import Debug
        s = String(str(val))
        Debug.log(s)
        try:
            ctx = get_security_context()
            ctx.emit_event('debug', {'value': s.value})
        except Exception:
            pass
        return NULL
    
    def eval_external_declaration(self, node, env, stack_trace):
        def _placeholder(*a): 
            return EvaluationError(f"External '{node.name.value}' not linked")
        
        env.set(node.name.value, Builtin(_placeholder, node.name.value))
        return NULL
    
    def eval_exactly_statement(self, node, env, stack_trace):
        return self.eval_node(node.body, env, stack_trace)
    
    def eval_action_statement(self, node, env, stack_trace):
        action = Action(node.parameters, node.body, env)
        
        # Apply modifiers if present
        modifiers = getattr(node, 'modifiers', [])
        if modifiers:
            # Set modifier flags on the action object
            if 'inline' in modifiers:
                action.is_inlined = True
            if 'async' in modifiers:
                action.is_async = True
            if 'secure' in modifiers:
                action.is_secure = True
            if 'pure' in modifiers:
                action.is_pure = True
            if 'native' in modifiers:
                action.is_native = True
            
            # 'public' modifier: automatically export the action
            if 'public' in modifiers:
                try:
                    env.export(node.name.value, action)
                except Exception:
                    pass
        
        env.set(node.name.value, action)
        return NULL
    
    def eval_function_statement(self, node, env, stack_trace):
        """Evaluate function statement - identical to action statement in Zexus"""
        print(f"[DEBUG] Defining function {node.name.value} in env {id(env)}")
        action = Action(node.parameters, node.body, env)
        
        # Apply modifiers if present
        modifiers = getattr(node, 'modifiers', [])
        if modifiers:
            # Set modifier flags on the action object
            if 'inline' in modifiers:
                action.is_inlined = True
            if 'async' in modifiers:
                action.is_async = True
            if 'secure' in modifiers:
                action.is_secure = True
            if 'pure' in modifiers:
                action.is_pure = True
            if 'native' in modifiers:
                action.is_native = True
            
            # 'public' modifier: automatically export the function
            if 'public' in modifiers:
                try:
                    env.export(node.name.value, action)
                except Exception:
                    pass
        
        env.set(node.name.value, action)
        return NULL
    
    # === PERFORMANCE OPTIMIZATION STATEMENTS ===
    
    def eval_native_statement(self, node, env, stack_trace):
        """Evaluate native statement - call C/C++ code directly."""
        try:
            import ctypes
            
            # Load the shared library
            try:
                lib = ctypes.CDLL(node.library_name)
            except (OSError, AttributeError) as e:
                return EvaluationError(f"Failed to load native library '{node.library_name}': {str(e)}")
            
            # Get the function from the library
            try:
                native_func = getattr(lib, node.function_name)
            except AttributeError:
                return EvaluationError(f"Function '{node.function_name}' not found in library '{node.library_name}'")
            
            # Evaluate arguments
            args = []
            for arg in node.args:
                val = self.eval_node(arg, env, stack_trace)
                if is_error(val):
                    return val
                # Convert Zexus objects to Python types for FFI
                args.append(_zexus_to_python(val))
            
            # Call the native function
            try:
                result = native_func(*args)
                # Convert result back to Zexus object
                zexus_result = _python_to_zexus(result)
                
                # Store result if alias provided
                if node.alias:
                    env.set(node.alias, zexus_result)
                
                return zexus_result
            except Exception as e:
                return EvaluationError(f"Error calling native function '{node.function_name}': {str(e)}")
        
        except ImportError:
            return EvaluationError("ctypes module required for native statements")
    
    def eval_gc_statement(self, node, env, stack_trace):
        """Evaluate garbage collection statement."""
        try:
            import gc
            
            action = node.action.lower()
            
            if action == "collect":
                # Force garbage collection
                collected = gc.collect()
                return Integer(collected)
            
            elif action == "pause":
                # Pause garbage collection
                gc.disable()
                return String("GC paused")
            
            elif action == "resume":
                # Resume garbage collection
                gc.enable()
                return String("GC resumed")
            
            elif action == "enable_debug":
                # Enable GC debug output
                gc.set_debug(gc.DEBUG_STATS)
                return String("GC debug enabled")
            
            elif action == "disable_debug":
                # Disable GC debug output
                gc.set_debug(0)
                return String("GC debug disabled")
            
            else:
                return EvaluationError(f"Unknown GC action: {action}")
        
        except Exception as e:
            return EvaluationError(f"Error in GC statement: {str(e)}")
    
    def eval_inline_statement(self, node, env, stack_trace):
        """Evaluate inline statement - mark function for inlining optimization."""
        # Get the function to inline
        func_name = node.function_name
        if isinstance(func_name, Identifier):
            func_name = func_name.value
        
        func = env.get(func_name)
        if func is None:
            return EvaluationError(f"Function '{func_name}' not found for inlining")
        
        # Mark function as inlined by setting a flag
        if hasattr(func, 'is_inlined'):
            func.is_inlined = True
        elif isinstance(func, Action):
            func.is_inlined = True
        elif isinstance(func, Builtin):
            func.is_inlined = True
        else:
            # Try to set the attribute dynamically
            try:
                func.is_inlined = True
            except:
                pass
        
        return String(f"Function '{func_name}' marked for inlining")
    
    def eval_buffer_statement(self, node, env, stack_trace):
        """Evaluate buffer statement - direct memory access and manipulation."""
        try:
            import array
            
            buffer_name = node.buffer_name
            operation = node.operation
            arguments = node.arguments
            
            if operation == "allocate":
                # allocate(size) - allocate a buffer
                if len(arguments) != 1:
                    return EvaluationError(f"allocate expects 1 argument, got {len(arguments)}")
                
                size_val = self.eval_node(arguments[0], env, stack_trace)
                if is_error(size_val):
                    return size_val
                
                size = _zexus_to_python(size_val)
                try:
                    size = int(size)
                    # Create a byte array as a simple buffer representation
                    buf = bytearray(size)
                    env.set(buffer_name, _python_to_zexus(buf))
                    return String(f"Buffer '{buffer_name}' allocated with size {size}")
                except (ValueError, TypeError):
                    return EvaluationError(f"Invalid size for buffer allocation: {size}")
            
            elif operation == "read":
                # buffer.read(offset, length)
                if len(arguments) != 2:
                    return EvaluationError(f"read expects 2 arguments, got {len(arguments)}")
                
                offset_val = self.eval_node(arguments[0], env, stack_trace)
                length_val = self.eval_node(arguments[1], env, stack_trace)
                
                if is_error(offset_val) or is_error(length_val):
                    return offset_val if is_error(offset_val) else length_val
                
                buf = env.get(buffer_name)
                if buf is None:
                    return EvaluationError(f"Buffer '{buffer_name}' not found")
                
                offset = _zexus_to_python(offset_val)
                length = _zexus_to_python(length_val)
                
                try:
                    offset, length = int(offset), int(length)
                    buf_data = _zexus_to_python(buf)
                    data = buf_data[offset:offset+length]
                    return _python_to_zexus(list(data))
                except Exception as e:
                    return EvaluationError(f"Error reading from buffer: {str(e)}")
            
            elif operation == "write":
                # buffer.write(offset, data)
                if len(arguments) != 2:
                    return EvaluationError(f"write expects 2 arguments, got {len(arguments)}")
                
                offset_val = self.eval_node(arguments[0], env, stack_trace)
                data_val = self.eval_node(arguments[1], env, stack_trace)
                
                if is_error(offset_val) or is_error(data_val):
                    return offset_val if is_error(offset_val) else data_val
                
                buf = env.get(buffer_name)
                if buf is None:
                    return EvaluationError(f"Buffer '{buffer_name}' not found")
                
                offset = _zexus_to_python(offset_val)
                data = _zexus_to_python(data_val)
                
                try:
                    offset = int(offset)
                    buf_data = _zexus_to_python(buf)
                    if isinstance(buf_data, (bytearray, list)):
                        if isinstance(data, list):
                            for i, byte in enumerate(data):
                                buf_data[offset + i] = int(byte)
                        else:
                            buf_data[offset] = int(data)
                    else:
                        return EvaluationError(f"Buffer is not writable")
                    return String(f"Wrote {len(data) if isinstance(data, list) else 1} bytes at offset {offset}")
                except Exception as e:
                    return EvaluationError(f"Error writing to buffer: {str(e)}")
            
            elif operation == "free":
                # free() - deallocate buffer
                buf = env.get(buffer_name)
                if buf is None:
                    return EvaluationError(f"Buffer '{buffer_name}' not found")
                
                env.delete(buffer_name)
                return String(f"Buffer '{buffer_name}' freed")
            
            else:
                return EvaluationError(f"Unknown buffer operation: {operation}")
        
        except Exception as e:
            return EvaluationError(f"Error in buffer statement: {str(e)}")
    
    def eval_simd_statement(self, node, env, stack_trace):
        """Evaluate SIMD statement - vector operations using SIMD instructions."""
        try:
            import numpy as np
            
            # Evaluate the SIMD operation expression
            result = self.eval_node(node.operation, env, stack_trace)
            
            if is_error(result):
                return result
            
            # Convert result to Zexus object
            zexus_result = result
            
            return zexus_result
        
        except ImportError:
            # Fallback to pure Python implementation if numpy not available
            result = self.eval_node(node.operation, env, stack_trace)
            return result if not is_error(result) else EvaluationError("SIMD operations require numpy or fallback implementation")
        
        except Exception as e:
            return EvaluationError(f"Error in SIMD statement: {str(e)}")
    
    def eval_defer_statement(self, node, env, stack_trace):
        """Evaluate defer statement - cleanup code execution."""
        # Store the deferred code for later execution (at end of scope/function)
        if not hasattr(env, '_deferred'):
            env._deferred = []
        
        env._deferred.append(node.code_block)
        return String(f"Deferred cleanup code registered")
    
    def eval_pattern_statement(self, node, env, stack_trace):
        """Evaluate pattern statement - pattern matching."""
        # Evaluate the expression to match
        value = self.eval_node(node.expression, env, stack_trace)
        if is_error(value):
            return value
        
        # Convert to comparable form
        match_value = _zexus_to_python(value)
        
        # Try each pattern case
        for case in node.cases:
            case_pattern = _zexus_to_python(case.pattern)
            
            # Match logic
            if case_pattern == "default" or case_pattern == match_value:
                # Execute action
                action_result = self.eval_node(case.action, env, stack_trace)
                return action_result
        
        # No match found
        return NULL
    
    def eval_enum_statement(self, node, env, stack_trace):
        """Evaluate enum statement - type-safe enumerations."""
        # Create an enum object
        enum_obj = Map()
        
        for i, member in enumerate(node.members):
            # Use provided value or auto-increment
            if member.value is not None:
                value = member.value
            else:
                value = i
            
            enum_obj.set(member.name, Integer(value) if isinstance(value, int) else String(value))
        
        # Store enum in environment
        env.set(node.name, enum_obj)
        return String(f"Enum '{node.name}' defined with {len(node.members)} members")
    
    def eval_stream_statement(self, node, env, stack_trace):
        """Evaluate stream statement - event streaming."""
        # Register stream handler
        if not hasattr(env, '_streams'):
            env._streams = {}
        
        # Store handler for stream
        env._streams[node.stream_name] = {
            'event_var': node.event_var,
            'handler': node.handler
        }
        
        return String(f"Stream '{node.stream_name}' handler registered")
    
    


    # === NEW SECURITY STATEMENT HANDLERS ===

    def eval_capability_statement(self, node, env, stack_trace):
        """Evaluate capability definition statement."""
        from ..capability_system import Capability, CapabilityLevel
        
        # Get capability name
        cap_name = node.name.value if hasattr(node.name, 'value') else str(node.name)
        
        # Extract definition details
        description = ""
        scope = ""
        level = CapabilityLevel.ALLOWED
        
        if node.definition and isinstance(node.definition, Map):
            # Extract from map
            for key, val in node.definition.pairs:
                if hasattr(key, 'value'):
                    if key.value == "description" and hasattr(val, 'value'):
                        description = val.value
                    elif key.value == "scope" and hasattr(val, 'value'):
                        scope = val.value
        
        # Create capability object
        cap = Capability(
            name=cap_name,
            level=level,
            reason=f"Defined with scope: {scope}"
        )
        
        # Store in environment both as identifier and in _capabilities
        if not hasattr(env, '_capabilities'):
            env._capabilities = {}
        env._capabilities[cap_name] = cap
        env.set(cap_name, cap)  # Also store as identifier so it can be referenced
        
        debug_log("eval_capability_statement", f"Defined capability: {cap_name} ({scope})")
        return cap  # Return the capability object instead of just a string

    def eval_grant_statement(self, node, env, stack_trace):
        """Evaluate grant statement - grant capabilities to entity."""
        from ..capability_system import get_capability_manager
        
        manager = get_capability_manager()
        
        # Get entity name
        entity_name = node.entity_name.value if hasattr(node.entity_name, 'value') else str(node.entity_name)
        
        # Extract capability names
        capability_names = []
        for cap in node.capabilities:
            if hasattr(cap, 'value'):
                capability_names.append(cap.value)
            elif hasattr(cap, 'function') and hasattr(cap.function, 'value'):
                # Function call style
                capability_names.append(cap.function.value)
            else:
                capability_names.append(str(cap))
        
        # Grant capabilities
        try:
            manager.grant_capabilities(entity_name, capability_names)
            debug_log("eval_grant_statement", f"Granted {len(capability_names)} capabilities to {entity_name}")
            return String(f"Granted {len(capability_names)} capabilities to '{entity_name}'")
        except Exception as e:
            return String(f"Error granting capabilities: {e}")

    def eval_revoke_statement(self, node, env, stack_trace):
        """Evaluate revoke statement - revoke capabilities from entity."""
        from ..capability_system import get_capability_manager
        
        manager = get_capability_manager()
        
        # Get entity name
        entity_name = node.entity_name.value if hasattr(node.entity_name, 'value') else str(node.entity_name)
        
        # Extract capability names
        capability_names = []
        for cap in node.capabilities:
            if hasattr(cap, 'value'):
                capability_names.append(cap.value)
            elif hasattr(cap, 'function') and hasattr(cap.function, 'value'):
                capability_names.append(cap.function.value)
            else:
                capability_names.append(str(cap))
        
        # Revoke by removing from granted set (simple implementation)
        # In production, this would use a proper revocation mechanism
        try:
            # Access the manager's granted_capabilities
            if entity_name in manager.granted_capabilities:
                for cap_name in capability_names:
                    manager.granted_capabilities[entity_name].discard(cap_name)
            
            debug_log("eval_revoke_statement", f"Revoked {len(capability_names)} capabilities from {entity_name}")
            return String(f"Revoked {len(capability_names)} capabilities from '{entity_name}'")
        except Exception as e:
            return String(f"Error revoking capabilities: {e}")

    def eval_validate_statement(self, node, env, stack_trace):
        """Evaluate validate statement - validate data against schema."""
        from ..validation_system import (
            get_validation_manager, ValidationError, StandardValidators
        )
        
        manager = get_validation_manager()
        
        # Evaluate data expression
        data = self.eval_node(node.data, env, stack_trace)
        
        # Evaluate schema
        schema = None
        if node.schema:
            if isinstance(node.schema, dict):
                schema = node.schema
            elif hasattr(node.schema, 'pairs'):  # Map object
                # Convert Map to dict
                schema = {}
                for key, val in node.schema.pairs:
                    key_str = key.value if hasattr(key, 'value') else str(key)
                    schema[key_str] = val
            else:
                schema = self.eval_node(node.schema, env, stack_trace)
        
        # Validate data
        try:
            if isinstance(data, String):
                # Validate string against pattern or standard validator
                if isinstance(schema, String):
                    validator_name = schema.value
                    if hasattr(StandardValidators, validator_name.upper()):
                        validator = getattr(StandardValidators, validator_name.upper())
                        if validator.validate(data.value):
                            return String(f"Validation passed for {validator_name}")
                        else:
                            return String(f"Validation failed: {validator.get_error_message()}")
            
            # For complex validation, use schema
            if schema and hasattr(data, '__dict__'):
                manager.validate_schema(vars(data), str(schema) if not isinstance(schema, dict) else "custom")
            
            debug_log("eval_validate_statement", "Validation passed")
            return String("Validation passed")
        
        except ValidationError as e:
            debug_log("eval_validate_statement", f"Validation error: {e}")
            return String(f"Validation failed: {e}")

    def eval_sanitize_statement(self, node, env, stack_trace):
        """Evaluate sanitize statement - sanitize untrusted input."""
        from ..validation_system import Sanitizer, Encoding, get_validation_manager
        
        manager = get_validation_manager()
        
        # Evaluate data to sanitize
        data = self.eval_node(node.data, env, stack_trace)
        
        # Convert to string
        if hasattr(data, 'value'):
            data_str = str(data.value)
        else:
            data_str = str(data)
        
        # Determine encoding
        encoding = Encoding.HTML  # Default
        if node.encoding:
            enc_val = self.eval_node(node.encoding, env, stack_trace)
            if hasattr(enc_val, 'value'):
                enc_name = enc_val.value.upper()
                try:
                    encoding = Encoding[enc_name]
                except KeyError:
                    encoding = Encoding.HTML
        
        # Sanitize
        try:
            sanitized = Sanitizer.sanitize_string(data_str, encoding)
            debug_log("eval_sanitize_statement", f"Sanitized {len(data_str)} chars with {encoding.value}")
            return String(sanitized)
        except Exception as e:
            debug_log("eval_sanitize_statement", f"Sanitization error: {e}")
            return String(data_str)  # Return original if sanitization fails

    def eval_inject_statement(self, node, env, stack_trace):
        """Evaluate inject statement - full dependency injection with mode-aware resolution."""
        from ..dependency_injection import get_di_registry, ExecutionMode
        from ..object import String as StringObj, Null as NullObj
        
        # Get dependency name
        dep_name = node.dependency.value if hasattr(node.dependency, 'value') else str(node.dependency)
        
        debug_log("eval_inject_statement", f"Resolving dependency: {dep_name}")
        
        # Get DI registry and current module context
        di_registry = get_di_registry()
        
        # Determine module name from environment context
        module_name = env.get("__module__") 
        module_name = module_name.value if module_name and hasattr(module_name, 'value') else "__main__"
        
        # Get or create container for this module
        container = di_registry.get_container(module_name)
        
        # Determine execution mode from environment or default to PRODUCTION
        mode_obj = env.get("__execution_mode__")
        if mode_obj and hasattr(mode_obj, 'value'):
            mode_str = mode_obj.value.upper()
            try:
                execution_mode = ExecutionMode[mode_str]
            except KeyError:
                execution_mode = ExecutionMode.PRODUCTION
        else:
            execution_mode = ExecutionMode.PRODUCTION
        
        # Set container's execution mode
        container.execution_mode = execution_mode
        
        try:
            # Attempt to resolve dependency
            resolved = container.get(dep_name)
            
            if resolved is not None:
                # Successfully resolved - store in environment
                env.set(dep_name, resolved)
                debug_log("eval_inject_statement", f"✓ Injected {dep_name} from container (mode: {execution_mode.name})")
                return StringObj(f"Dependency '{dep_name}' injected ({execution_mode.name} mode)")
            else:
                # Dependency not registered - create null placeholder
                debug_log("eval_inject_statement", f"⚠ Dependency {dep_name} not registered, using null")
                env.set(dep_name, NullObj())
                return StringObj(f"Warning: Dependency '{dep_name}' not registered")
                
        except Exception as e:
            # Error during resolution
            debug_log("eval_inject_statement", f"✗ Error injecting {dep_name}: {e}")
            env.set(dep_name, NullObj())
            return StringObj(f"Error: Could not inject '{dep_name}': {str(e)}")

    def eval_immutable_statement(self, node, env, stack_trace):
        """Evaluate immutable statement - declare variable as immutable."""
        from ..purity_system import get_immutability_manager
        
        manager = get_immutability_manager()
        
        # Get variable name
        var_name = node.target.value if hasattr(node.target, 'value') else str(node.target)
        
        # Evaluate and assign value if provided
        if node.value:
            value = self.eval_node(node.value, env, stack_trace)
            env.set(var_name, value)
            
            # Mark as immutable
            manager.mark_immutable(value)
            debug_log("eval_immutable_statement", f"Created immutable: {var_name}")
            return String(f"Immutable variable '{var_name}' created")
        else:
            # Mark existing variable as immutable
            try:
                value = env.get(var_name)
                manager.mark_immutable(value)
                debug_log("eval_immutable_statement", f"Marked immutable: {var_name}")
                return String(f"Variable '{var_name}' marked as immutable")
            except Exception as e:
                return String(f"Error: Variable '{var_name}' not found")


    # === COMPLEXITY & LARGE PROJECT MANAGEMENT STATEMENT EVALUATORS ===

    def eval_interface_statement(self, node, env, stack_trace):
        """Evaluate interface statement - define a contract/interface."""
        from ..complexity_system import get_complexity_manager
        
        manager = get_complexity_manager()
        
        # Get interface name
        interface_name = node.name.value if hasattr(node.name, 'value') else str(node.name)
        
        # Create interface from AST node
        from ..complexity_system import Interface
        interface = Interface(
            name=interface_name,
            methods=node.methods if hasattr(node, 'methods') else [],
            properties=node.properties if hasattr(node, 'properties') else {}
        )
        
        # Register interface
        manager.register_interface(interface)
        debug_log("eval_interface_statement", f"Registered interface: {interface_name}")
        
        # Store in environment
        env.set(interface_name, interface)
        return String(f"Interface '{interface_name}' defined")

    def eval_type_alias_statement(self, node, env, stack_trace):
        """Evaluate type alias statement - create type name shortcuts."""
        from ..complexity_system import get_complexity_manager
        
        manager = get_complexity_manager()
        
        # Get type alias name
        alias_name = node.name.value if hasattr(node.name, 'value') else str(node.name)
        
        # Get base type (just the string name, don't evaluate as expression)
        base_type = node.base_type.value if hasattr(node.base_type, 'value') else str(node.base_type)
        
        # Create type alias
        from ..complexity_system import TypeAlias
        alias = TypeAlias(
            name=alias_name,
            base_type=base_type
        )
        
        # Register type alias
        manager.register_type_alias(alias)
        debug_log("eval_type_alias_statement", f"Registered type alias: {alias_name} -> {base_type}")
        
        # Store in environment
        env.set(alias_name, alias)
        return String(f"Type alias '{alias_name}' defined")

    def eval_module_statement(self, node, env, stack_trace):
        """Evaluate module statement - create namespaced module."""
        from ..complexity_system import get_complexity_manager, Module, ModuleMember, Visibility
        
        manager = get_complexity_manager()
        
        # Get module name
        module_name = node.name.value if hasattr(node.name, 'value') else str(node.name)
        
        # Create module
        module = Module(name=module_name)
        
        # Execute module body in new environment
        module_env = Environment(outer=env)
        
        if hasattr(node, 'body') and node.body:
            body_result = self.eval_node(node.body, module_env, stack_trace)
        
        # Collect module members using AST modifiers when available
        seen = set()
        if hasattr(node, 'body') and getattr(node.body, 'statements', None):
            for stmt in node.body.statements:
                # Determine declared name and modifiers if present
                declared_name = None
                modifiers = getattr(stmt, 'modifiers', []) or []

                # Function / Action declarations
                if type(stmt).__name__ in ('FunctionStatement', 'ActionStatement'):
                    if hasattr(stmt.name, 'value'):
                        declared_name = stmt.name.value
                    else:
                        declared_name = str(stmt.name)
                    member_type = 'function'

                # Let / Const declarations
                elif type(stmt).__name__ in ('LetStatement', 'ConstStatement'):
                    if hasattr(stmt.name, 'value'):
                        declared_name = stmt.name.value
                    else:
                        declared_name = str(stmt.name)
                    member_type = 'variable'

                else:
                    # Not a direct declaration we can extract; skip to env-scan fallback
                    continue

                if declared_name:
                    seen.add(declared_name)
                    try:
                        value = module_env.get(declared_name)
                    except Exception:
                        value = None

                    # Map modifiers to visibility
                    vis = Visibility.PUBLIC
                    lower_mods = [m.lower() for m in modifiers]
                    if 'private' in lower_mods or 'internal' in lower_mods:
                        vis = Visibility.INTERNAL
                    elif 'protected' in lower_mods:
                        vis = Visibility.PROTECTED

                    member = ModuleMember(
                        name=declared_name,
                        member_type=member_type,
                        visibility=vis,
                        value=value
                    )
                    module.add_member(member)

        # Fallback: include any remaining env keys not discovered via AST
        for key in module_env.store:
            if key.startswith('_') or key in seen:
                continue
            try:
                value = module_env.get(key)
            except Exception:
                value = None
            try:
                is_callable = callable(value)
            except Exception:
                is_callable = False
            member_type = 'function' if is_callable else 'variable'
            member = ModuleMember(
                name=key,
                member_type=member_type,
                visibility=Visibility.PUBLIC,
                value=value
            )
            module.add_member(member)
        
        # Note: Module is stored directly in environment; manager integration can be enhanced later
        debug_log("eval_module_statement", f"Created module: {module_name}")
        debug_log("eval_module_statement", f"Module members: {list(module.members.keys())}")
        
        # Store in environment
        env.set(module_name, module)
        return String(f"Module '{module_name}' created")

    def eval_package_statement(self, node, env, stack_trace):
        """Evaluate package statement - create package with hierarchical support."""
        from ..complexity_system import get_complexity_manager, Package
        
        manager = get_complexity_manager()
        
        # Get package name (may be dotted like app.api.v1)
        package_name = node.name.value if hasattr(node.name, 'value') else str(node.name)
        
        # Parse hierarchical package names
        name_parts = package_name.split('.')
        
        # Create the leaf package with body content
        leaf_package = Package(name=name_parts[-1])
        
        # Execute package body in new environment
        package_env = Environment(outer=env)
        
        if hasattr(node, 'body') and node.body:
            body_result = self.eval_node(node.body, package_env, stack_trace)
        
        # Collect package members from package environment
        for key in package_env.store:
            if not key.startswith('_'):
                value = package_env.get(key)
                leaf_package.modules[key] = value
        
        debug_log("eval_package_statement", f"Created package: {package_name} with members: {list(leaf_package.modules.keys())}")
        
        # Handle hierarchical package structure
        if len(name_parts) == 1:
            # Simple package (no hierarchy)
            env.set(package_name, leaf_package)
        else:
            # Hierarchical package - ensure all ancestors exist
            # Start from root and work down to leaf
            root_name = name_parts[0]
            root_package = env.get(root_name)
            
            if root_package is None or not hasattr(root_package, 'modules'):
                # Create root package if it doesn't exist
                root_package = Package(name=root_name)
                env.set(root_name, root_package)
                debug_log("eval_package_statement", f"Created root package: {root_name}")
            
            # Navigate/create intermediate packages
            current = root_package
            for i in range(1, len(name_parts)):
                part_name = name_parts[i]
                
                if i == len(name_parts) - 1:
                    # This is the leaf - add it
                    current.modules[part_name] = leaf_package
                    debug_log("eval_package_statement", f"Added {part_name} to {name_parts[i-1]}")
                else:
                    # This is an intermediate package
                    if part_name not in current.modules:
                        # Create intermediate package
                        intermediate = Package(name=part_name)
                        current.modules[part_name] = intermediate
                        debug_log("eval_package_statement", f"Created intermediate package: {part_name}")
                    current = current.modules[part_name]
        
        return String(f"Package '{package_name}' created")

    def eval_using_statement(self, node, env, stack_trace):
        """Evaluate using statement - RAII pattern for resource management."""
        from ..complexity_system import get_complexity_manager
        
        manager = get_complexity_manager()
        
        # Get resource name
        resource_name = node.resource_name.value if hasattr(node.resource_name, 'value') else str(node.resource_name)
        
        # Acquire resource
        resource = self.eval_node(node.resource_expr, env, stack_trace)
        
        # Store resource in environment
        env.set(resource_name, resource)
        
        try:
            debug_log("eval_using_statement", f"Acquired resource: {resource_name}")
            
            # Execute body in using block
            if hasattr(node, 'body') and node.body:
                body_result = self.eval_node(node.body, env, stack_trace)
            
            return body_result if 'body_result' in locals() else NULL
        
        finally:
            # Cleanup resource (RAII)
            if hasattr(resource, 'close'):
                try:
                    resource.close()
                    debug_log("eval_using_statement", f"Closed resource: {resource_name}")
                except Exception as e:
                    debug_log("eval_using_statement", f"Error closing resource: {e}")
            elif hasattr(resource, 'cleanup'):
                try:
                    resource.cleanup()
                    debug_log("eval_using_statement", f"Cleaned up resource: {resource_name}")
                except Exception as e:
                    debug_log("eval_using_statement", f"Error cleaning up resource: {e}")

    # === CONCURRENCY & PERFORMANCE STATEMENT EVALUATORS ===

    def eval_channel_statement(self, node, env, stack_trace):
        """Evaluate channel statement - declare a message passing channel."""
        from ..concurrency_system import get_concurrency_manager
        
        manager = get_concurrency_manager()
        
        # Get channel name
        channel_name = node.name.value if hasattr(node.name, 'value') else str(node.name)
        
        # Get element type if specified
        element_type = None
        if hasattr(node, 'element_type') and node.element_type:
            element_type = str(node.element_type)
        
        # Get capacity if specified
        capacity = 0
        if hasattr(node, 'capacity') and node.capacity:
            capacity = self.eval_node(node.capacity, env, stack_trace)
            if isinstance(capacity, Integer):
                capacity = capacity.value
            else:
                capacity = 0
        
        # Create channel
        channel = manager.create_channel(channel_name, element_type, capacity)
        debug_log("eval_channel_statement", f"Created channel: {channel_name}")
        
        # Store in environment
        env.set(channel_name, channel)
        return String(f"Channel '{channel_name}' created")

    def eval_send_statement(self, node, env, stack_trace):
        """Evaluate send statement - send value to a channel."""
        from ..concurrency_system import get_concurrency_manager
        
        manager = get_concurrency_manager()
        
        # Evaluate channel expression
        channel = self.eval_node(node.channel_expr, env, stack_trace)
        
        # Evaluate value to send
        value = self.eval_node(node.value_expr, env, stack_trace)
        
        # Send to channel
        if hasattr(channel, 'send'):
            try:
                channel.send(value, timeout=5.0)
                debug_log("eval_send_statement", f"Sent to channel: {value}")
                return String(f"Value sent to channel")
            except Exception as e:
                return String(f"Error sending to channel: {e}")
        else:
            return String(f"Error: not a valid channel")

    def eval_receive_statement(self, node, env, stack_trace):
        """Evaluate receive statement - receive value from a channel."""
        from ..concurrency_system import get_concurrency_manager
        
        manager = get_concurrency_manager()
        
        # Evaluate channel expression
        channel = self.eval_node(node.channel_expr, env, stack_trace)
        
        # Receive from channel
        if hasattr(channel, 'receive'):
            try:
                value = channel.receive(timeout=5.0)
                debug_log("eval_receive_statement", f"Received from channel: {value}")
                
                # Bind to target if specified
                if hasattr(node, 'target') and node.target:
                    target_name = node.target.value if hasattr(node.target, 'value') else str(node.target)
                    env.set(target_name, value)
                
                return value if value is not None else NULL
            except Exception as e:
                return String(f"Error receiving from channel: {e}")
        else:
            return String(f"Error: not a valid channel")

    def eval_atomic_statement(self, node, env, stack_trace):
        """Evaluate atomic statement - execute indivisible operation."""
        from ..concurrency_system import get_concurrency_manager
        
        manager = get_concurrency_manager()
        
        # Create/get atomic region
        atomic_id = f"atomic_{id(node)}"
        atomic = manager.create_atomic(atomic_id)
        
        # Execute atomically
        def execute_block():
            if hasattr(node, 'body') and node.body:
                # Atomic block
                return self.eval_node(node.body, env, stack_trace)
            elif hasattr(node, 'expr') and node.expr:
                # Atomic expression
                return self.eval_node(node.expr, env, stack_trace)
            return NULL
        
        result = atomic.execute(execute_block)
        debug_log("eval_atomic_statement", "Atomic operation completed")
        
        return result if result is not NULL else NULL

    # === BLOCKCHAIN STATEMENT EVALUATION ===
    
    def eval_ledger_statement(self, node, env, stack_trace):
        """Evaluate ledger statement - create immutable ledger variable.
        
        ledger balances = {};
        ledger state_root;
        """
        from ..blockchain import Ledger
        from ..blockchain.transaction import get_current_tx, create_tx_context
        
        debug_log("eval_ledger_statement", f"ledger {node.name.value}")
        
        # Ensure TX context exists
        tx = get_current_tx()
        if tx is None:
            tx = create_tx_context(caller="system", gas_limit=1000000)
        
        # Evaluate initial value if provided
        initial_value = NULL
        if node.initial_value:
            initial_value = self.eval_node(node.initial_value, env, stack_trace)
            if is_error(initial_value):
                return initial_value
        
        # Create ledger instance
        ledger_name = node.name.value
        ledger = Ledger(ledger_name)
        
        # Write initial value if provided
        if initial_value != NULL:
            # Convert Zexus object to Python value for storage
            py_value = _zexus_to_python(initial_value)
            ledger.write(ledger_name, py_value, tx.block_hash)
        
        # Store the value directly in environment (ledger is for tracking history)
        env.set(node.name.value, initial_value)
        
        debug_log("eval_ledger_statement", f"Created ledger: {node.name.value}")
        return NULL
    
    def eval_state_statement(self, node, env, stack_trace):
        """Evaluate state statement - create mutable state variable.
        
        state counter = 0;
        state owner = TX.caller;
        """
        debug_log("eval_state_statement", f"state {node.name.value}")
        
        # Evaluate initial value
        value = NULL
        if node.initial_value:
            value = self.eval_node(node.initial_value, env, stack_trace)
            if is_error(value):
                return value
        
        # Store in environment (regular mutable variable)
        env.set(node.name.value, value)
        
        debug_log("eval_state_statement", f"Created state: {node.name.value}")
        return NULL
    
    def eval_require_statement(self, node, env, stack_trace):
        """Evaluate require statement - assert condition or revert.
        
        require(balance >= amount);
        require(TX.caller == owner, "Only owner");
        """
        debug_log("eval_require_statement", "Checking condition")
        
        # Evaluate condition
        condition = self.eval_node(node.condition, env, stack_trace)
        if is_error(condition):
            return condition
        
        # Check if condition is true
        if not is_truthy(condition):
            # Evaluate error message if provided
            message = "Requirement failed"
            if node.message:
                msg_val = self.eval_node(node.message, env, stack_trace)
                if isinstance(msg_val, String):
                    message = msg_val.value
                elif not is_error(msg_val):
                    message = str(msg_val.inspect() if hasattr(msg_val, 'inspect') else msg_val)
            
            # Trigger revert
            debug_log("eval_require_statement", f"REVERT: {message}")
            return EvaluationError(f"Transaction reverted: {message}", stack_trace=stack_trace)
        
        debug_log("eval_require_statement", "Requirement passed")
        return NULL
    
    def eval_revert_statement(self, node, env, stack_trace):
        """Evaluate revert statement - rollback transaction.
        
        revert();
        revert("Unauthorized");
        """
        debug_log("eval_revert_statement", "Reverting transaction")
        
        # Evaluate revert reason if provided
        reason = "Transaction reverted"
        if node.reason:
            reason_val = self.eval_node(node.reason, env, stack_trace)
            if isinstance(reason_val, String):
                reason = reason_val.value
            elif not is_error(reason_val):
                reason = str(reason_val.inspect() if hasattr(reason_val, 'inspect') else reason_val)
        
        debug_log("eval_revert_statement", f"REVERT: {reason}")
        return EvaluationError(f"Transaction reverted: {reason}", stack_trace=stack_trace)
    
    def eval_limit_statement(self, node, env, stack_trace):
        """Evaluate limit statement - set gas limit.
        
        limit(5000);
        """
        from ..blockchain import get_current_tx
        
        debug_log("eval_limit_statement", "Setting gas limit")
        
        # Evaluate gas limit amount
        limit_val = self.eval_node(node.gas_limit, env, stack_trace)
        if is_error(limit_val):
            return limit_val
        
        # Extract numeric value
        if isinstance(limit_val, Integer):
            limit_amount = limit_val.value
        else:
            return EvaluationError(f"Gas limit must be an integer, got {type(limit_val).__name__}")
        
        # Get current transaction context
        tx = get_current_tx()
        if tx:
            tx.gas_limit = limit_amount
            debug_log("eval_limit_statement", f"Set gas limit to {limit_amount}")
        else:
            debug_log("eval_limit_statement", "No active TX context, limit statement ignored")
        
        return NULL
    
    # === BLOCKCHAIN EXPRESSION EVALUATION ===
    
    def eval_tx_expression(self, node, env, stack_trace):
        """Evaluate TX expression - access transaction context.
        
        TX.caller
        TX.timestamp
        TX.gas_remaining
        """
        from ..blockchain import get_current_tx
        
        tx = get_current_tx()
        if not tx:
            debug_log("eval_tx_expression", "No active TX context")
            return NULL
        
        # If no property specified, return the TX object itself
        if not node.property_name:
            # Wrap TX context as Zexus object
            return _python_to_zexus(tx)
        
        # Access specific property
        prop = node.property_name
        if prop == "caller":
            return String(tx.caller)
        elif prop == "timestamp":
            return Integer(tx.timestamp)
        elif prop == "block_hash":
            return String(tx.block_hash)
        elif prop == "gas_limit":
            return Integer(tx.gas_limit)
        elif prop == "gas_used":
            return Integer(tx.gas_used)
        elif prop == "gas_remaining":
            return Integer(tx.gas_remaining)
        else:
            return EvaluationError(f"Unknown TX property: {prop}")
    
    def eval_hash_expression(self, node, env, stack_trace):
        """Evaluate hash expression - cryptographic hashing.
        
        hash(data, "SHA256")
        hash(message, "KECCAK256")
        """
        from ..blockchain.crypto import CryptoPlugin
        
        # Evaluate data to hash
        data_val = self.eval_node(node.data, env, stack_trace)
        if is_error(data_val):
            return data_val
        
        # Evaluate algorithm
        algorithm_val = self.eval_node(node.algorithm, env, stack_trace)
        if is_error(algorithm_val):
            return algorithm_val
        
        # Convert to string values
        if isinstance(data_val, String):
            data = data_val.value
        else:
            data = str(data_val.inspect() if hasattr(data_val, 'inspect') else data_val)
        
        if isinstance(algorithm_val, String):
            algorithm = algorithm_val.value
        else:
            algorithm = str(algorithm_val)
        
        # Perform hashing
        try:
            hash_result = CryptoPlugin.hash_data(data, algorithm)
            return String(hash_result)
        except Exception as e:
            return EvaluationError(f"Hash error: {str(e)}")
    
    def eval_signature_expression(self, node, env, stack_trace):
        """Evaluate signature expression - create digital signature.
        
        signature(data, private_key, "ECDSA")
        """
        from ..blockchain.crypto import CryptoPlugin
        
        # Evaluate arguments
        data_val = self.eval_node(node.data, env, stack_trace)
        if is_error(data_val):
            return data_val
        
        key_val = self.eval_node(node.private_key, env, stack_trace)
        if is_error(key_val):
            return key_val
        
        algorithm_val = self.eval_node(node.algorithm, env, stack_trace) if node.algorithm else String("ECDSA")
        if is_error(algorithm_val):
            return algorithm_val
        
        # Convert to string values
        data = data_val.value if isinstance(data_val, String) else str(data_val)
        private_key = key_val.value if isinstance(key_val, String) else str(key_val)
        algorithm = algorithm_val.value if isinstance(algorithm_val, String) else str(algorithm_val)
        
        # Create signature
        try:
            signature = CryptoPlugin.sign_data(data, private_key, algorithm)
            return String(signature)
        except Exception as e:
            return EvaluationError(f"Signature error: {str(e)}")
    
    def eval_verify_signature_expression(self, node, env, stack_trace):
        """Evaluate verify_sig expression - verify digital signature.
        
        verify_sig(data, signature, public_key, "ECDSA")
        """
        from ..blockchain.crypto import CryptoPlugin
        
        # Evaluate arguments
        data_val = self.eval_node(node.data, env, stack_trace)
        if is_error(data_val):
            return data_val
        
        sig_val = self.eval_node(node.signature, env, stack_trace)
        if is_error(sig_val):
            return sig_val
        
        key_val = self.eval_node(node.public_key, env, stack_trace)
        if is_error(key_val):
            return key_val
        
        algorithm_val = self.eval_node(node.algorithm, env, stack_trace) if node.algorithm else String("ECDSA")
        if is_error(algorithm_val):
            return algorithm_val
        
        # Convert to string values
        data = data_val.value if isinstance(data_val, String) else str(data_val)
        signature = sig_val.value if isinstance(sig_val, String) else str(sig_val)
        public_key = key_val.value if isinstance(key_val, String) else str(key_val)
        algorithm = algorithm_val.value if isinstance(algorithm_val, String) else str(algorithm_val)
        
        # Verify signature
        try:
            is_valid = CryptoPlugin.verify_signature(data, signature, public_key, algorithm)
            return TRUE if is_valid else FALSE
        except Exception as e:
            return EvaluationError(f"Signature verification error: {str(e)}")
    
    def eval_gas_expression(self, node, env, stack_trace):
        """Evaluate gas expression - access gas tracking.
        
        gas.used
        gas.remaining
        gas.limit
        """
        from ..blockchain import get_current_tx
        
        tx = get_current_tx()
        if not tx:
            debug_log("eval_gas_expression", "No active TX context")
            return NULL
        
        # If no property specified, return gas info as object
        if not node.property_name:
            gas_info = {
                "limit": Integer(tx.gas_limit),
                "used": Integer(tx.gas_used),
                "remaining": Integer(tx.gas_remaining)
            }
            return Map(gas_info)
        
        # Access specific property
        prop = node.property_name
        if prop == "limit":
            return Integer(tx.gas_limit)
        elif prop == "used":
            return Integer(tx.gas_used)
        elif prop == "remaining":
            return Integer(tx.gas_remaining)
        else:
            return EvaluationError(f"Unknown gas property: {prop}")
