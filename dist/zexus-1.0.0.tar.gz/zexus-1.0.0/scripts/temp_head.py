# evaluator.py (COMPLETE FIXED VERSION WITH COMPARISON OPERATORS)
from zexus_ast import *
from object import *

NULL, TRUE, FALSE = Null(), Boolean(True), Boolean(False)
